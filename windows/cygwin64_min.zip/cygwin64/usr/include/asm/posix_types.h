/* asm/posix_types.h

This file is part of Cygwin.

This software is a copyrighted work licensed under the terms of the
Cygwin license.  Please consult the file "CYGWIN_LICENSE" for
details. */

#ifndef _ASM_POSIX_TYPES_H
#define _ASM_POSIX_TYPES_H

/* This is just a placeholder to simplify cross-compiling the Linux kernel */

#endif /* _ASM_POSIX_TYPES_H */
