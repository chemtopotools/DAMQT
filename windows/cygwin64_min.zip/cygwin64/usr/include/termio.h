/* termio.h

This file is part of Cygwin.

This software is a copyrighted work licensed under the terms of the
Cygwin license.  Please consult the file "CYGWIN_LICENSE" for
details. */

#ifndef _TERMIO_H
#define _TERMIO_H

#include <sys/termio.h>

#endif
