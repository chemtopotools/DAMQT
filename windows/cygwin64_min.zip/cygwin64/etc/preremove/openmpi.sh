if [ -f /etc/openmpi-default-hostfile ] && cmp -s /etc/defaults/etc/openmpi-default-hostfile /etc/openmpi-default-hostfile
then
    rm /etc/openmpi-default-hostfile
fi

if [ -f /etc/openmpi-mca-params.conf ] && cmp -s /etc/defaults/etc/openmpi-mca-params.conf /etc/openmpi-mca-params.conf
then
    rm /etc/openmpi-mca-params.conf
fi

if [ -f /etc/openmpi-totalview.tcl ] && cmp -s /etc/defaults/etc/openmpi-totalview.tcl /etc/openmpi-totalview.tcl
then
    rm /etc/openmpi-totalview.tcl
fi

if [ -f /etc/pmix-mca-params.conf ] && cmp -s /etc/defaults/etc/pmix-mca-params.conf /etc/pmix-mca-params.conf
then
    rm /etc/pmix-mca-params.conf
fi

